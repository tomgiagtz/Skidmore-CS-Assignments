/**
* Simulates an ARMv8 CPU following the datapath from Figure 4.23 in the textbook.
*
* @author <student's name>
*/
import java.io.*;
import java.util.*;

public class CPU {

    /** Flag to inidcate whether or not in grading mode. Grading mode prints additional messages. */
    private static final boolean GRADING = true;

    /** Memory unit for instructions */
    private Memory instructionMemory;

    /** Memory unit for data */
    private Memory dataMemory;

    /** Register unit */
    private Registers registers;

    /** Arithmetic and logic unit */
    private ALU alu;

    /** Adder for incrementing the program counter */
    private ALU adderPC;

    /** Adder for computing branches */
    private ALU adderBranch;

    /** Control unit */
    private SimpleControl control;

    /** Multiplexor output connects to Read Register 2 */
    private Multiplexor2 muxRegRead2;

    /** Mulitplexor ouptut connects to ALU input B */
    private Multiplexor2 muxALUb;

    /** Multiplexor output connects to Register Write Data */
    private Multiplexor2 muxRegWriteData;

    /** Multiplexor outptu connects to Program Counter */
    private Multiplexor2 muxPC;

    /** Program counter */
    private boolean[] pc;

    /**
    * STUDENT SHOULD NOT MODIFY THIS METHOD
    *
    * Constructor initializes all data members.
    *
    * @param iMemFile Path to the file with instruction memory contents.
    * @param dMemFile Path to the file with data memory contents.
    * @exception FileNotFoundException if a file cannot be opened.
    */
    public CPU(String iMemFile, String dMemFile) throws FileNotFoundException {

        // Create objects for all data members
        instructionMemory = new Memory(iMemFile);
        dataMemory = new Memory(dMemFile);
        registers = new Registers();
        alu = new ALU();
        control = new SimpleControl();
        muxRegRead2 = new Multiplexor2(5);
        muxALUb = new Multiplexor2(32);
        muxRegWriteData = new Multiplexor2(32);
        muxPC = new Multiplexor2(32);


        // Activate adderPC with ADD operation, and inputB set to 4
        // Send adderPC output to muxPC input 0
        adderPC = new ALU();
        adderPC.setControl(2);
        boolean[] four = Binary.uDecToBin(4L);
        adderPC.setInputB(four);

        // Initalize adderBranch with ADD operation
        adderBranch = new ALU();
        adderBranch.setControl(2);

        // initialize program counter to 0
        pc = new boolean[32];
        for(int i = 0; i < 32; i++) {
            pc[i] = false;
        }
    }

    /**
    * STUDENT SHOULD NOT MODIFY THIS METHOD
    *
    * Runs the CPU (fetch, decode, execute cycle). Stops when a halt instruction
    * is reached.
    */
    public void run() throws FileNotFoundException {

        boolean[] instruction = fetch();
        boolean op = decode(instruction);

        // Loop until a halt instruction is decoded
        while(op) {
            execute();

            instruction = fetch();

            op = decode(instruction);
        }

        if(GRADING) {
            // Write memory contents to a file
            dataMemory.writeToFile("checkMem.txt");
        }
    }

    /**
    * STUDENT MUST COMPLETE THIS METHOD
    *
    * Fetch the instruction from the instruction memory starting at address pc.
    *
    * @return The instruction starting at address pc
    */
    private boolean[] fetch() {

        // WRITE CODE TO COMPLETE THIS METHOD

        // placeholder return, replace with correct return of instruction
        return new boolean[32];
    }

    /**
    * STUDENT MUST COMPLETE THIS METHOD
    *
    * Decode the instruction. Sets the control lines and sends appropriate bits
    * from the instruction to various inputs within the processor.
    *
    * @param instruction The 32-bit instruction to decode
    * @return false if the opcode is HLT; true for any other opcode
    */
    private boolean decode(boolean[] instruction) {

        // WRITE CODE TO COMPLETE THIS METHOD

        // placeholder return, replace with correct return value
        return false;
    }

    /**
    * STUDENT MUST COMPLETE THIS METHOD
    *
    * Execute the instruction.
    *
    */
    private void execute() {

        // WRITE CODE TO COMPLETE THIS METHOD

    }
}
